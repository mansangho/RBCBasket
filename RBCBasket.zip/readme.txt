This is a RBC Basket demo as requested for the specification outline below

Write a program that takes a basket of items and outputs its total cost.
The basket can contain one or more of the following items: Bananas, Oranges, Apples, Lemons, Peaches

It is implemented using Netbeans IDE version 8.
It uses Java 1.8 SE SDK. It uses some features of 8 (lambdas and interface functions).

To run the Demo.

1) type runme.cmd
